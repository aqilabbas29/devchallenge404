<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inconsolata:wght@900&display=swap" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" />
    <style media="screen">
      .txtdiv1
      {
        font-family: 'Inconsolata';
        font-weight: 700;
        font-size:24px;
      }
      .divgrid
        {
          display: grid;
          grid-template-columns: auto auto;
        }
        .divin1
        {
          /* width: 49%; */
          border: 1px solid black !important;
          /* float:left; */
        }
        .divin2
        {
          /* width:49%; */
          border: 1px solid brown;
          /* float: right; */
        }
      @media screen and (max-width: 376px) and (max-height: 950px) {
          .divgrid
        {
          display: grid;
          grid-template-columns: auto;
        }
        .divin1
        {
          /* width: 49%; */
          border: 1px solid blue;
          /* float:left; */
        }
        .divin2
        {
          /* width:49%; */
          border: 1px solid red;
          /* float: right; */
        }
      }
      img
      {
        width:50%;
        margin:auto;
      }
      .p21
      {
        font-family: "Space Mono";
        font-style: normal;
        font-weight: bold;
        font-size: 64px;
        line-height: 95px;
        letter-spacing: -0.035em;

        /* Gray 1 */

        color: #333333;
        width:50%;
      }
      .p22
      {
        width: 50%;
        font-family: Space Mono;
        font-style: normal;
        font-weight: normal;
        font-size: 24px;
        line-height: 36px;
        letter-spacing: -0.035em;

        /* Gray 2 */

        color: #4F4F4F;
      }
      .btn
      {
        background: #333333;
        font-family: Space Mono;
        font-style: normal;
        font-weight: bold;
        font-size: 14px;
        line-height: 21px;
        /* identical to box height */

        letter-spacing: -0.035em;
        text-transform: uppercase;

        color: #FFFFFF;
        width: 50%;
      }
    </style>
  </head>
  <body>

    <div class="txtdiv1">
      <p>404 NOT FOUND</p>
    </div>

    <div class="divgrid">
      <div class="divin1">
        <img src="Scarecrow.png" alt="" width="50%">
      </div>
      <div class="divin2">
        <div class="p21">
          <p >I have bad news for you</p>
        </div>
        <div>
          <p class="p22">The page you are looking for might be removed or is temporarily unavailable</p>
        </div>
        <div>
          <button class="btn">BACK TO HOMEPAGE</button>
        </div>
      </div>
    </div>
  </body>
</html>
